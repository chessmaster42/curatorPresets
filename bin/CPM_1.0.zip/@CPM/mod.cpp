name="Curator Presets Modules";
picture="curator_module_logo_ca.paa";
action="http://www.google.com";
actionName="Website";
description = "Adds Modules To The Editor For Curator Presets";