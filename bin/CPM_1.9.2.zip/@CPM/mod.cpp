name="Curator Presets Modules";
picture="curator_module_logo_ca.paa";
action="https://github.com/chessmaster42/curatorPresets";
actionName="Website";
description = "Adds Modules To The Editor For Curator Presets";